-- Create the Warehouse database if it doesn't exist
CREATE SCHEMA IF NOT EXISTS `Warehouse` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `Warehouse` ;

-- Create Customers table
CREATE TABLE IF NOT EXISTS `Customers` (
  `CustomerId` INT NOT NULL AUTO_INCREMENT,
  `CustomerName` VARCHAR(50) NOT NULL,
  `ContactPerson` VARCHAR(50) NULL,
  `Address` VARCHAR(50) NULL,
  `City` VARCHAR(50) NULL,
  `PostCode` VARCHAR(10) NULL,
  `Country` VARCHAR(50) NULL,
  PRIMARY KEY (`CustomerId`)
);

-- Create Employees table
CREATE TABLE IF NOT EXISTS `Employees` (
  `EmployeeId` INT NOT NULL AUTO_INCREMENT,
  `LastName` VARCHAR(50) NOT NULL,
  `FirstName` VARCHAR(50) NOT NULL,
  `BirthDate` DATE NULL,
  PRIMARY KEY (`EmployeeId`)
);

-- Create Suppliers table
CREATE TABLE IF NOT EXISTS `Suppliers` (
  `SupplierId` INT NOT NULL AUTO_INCREMENT,
  `SupplierName` VARCHAR(50) NOT NULL,
  `ContactPerson` VARCHAR(50) NULL,
  `Address` VARCHAR(50) NULL,
  `City` VARCHAR(50) NULL,
  `PostCode` VARCHAR(10) NULL,
  `Country` VARCHAR(50) NULL,
  `Phone` VARCHAR(20) NULL,
  PRIMARY KEY (`SupplierId`)
);

-- Create Shippers table
CREATE TABLE IF NOT EXISTS `Shippers` (
  `ShipperId` INT NOT NULL AUTO_INCREMENT,
  `ShipperName` VARCHAR(50) NOT NULL,
  `Phone` VARCHAR(20) NULL,
  PRIMARY KEY (`ShipperId`)
);

-- Create Products table
CREATE TABLE IF NOT EXISTS `Products` (
  `ProductId` INT NOT NULL AUTO_INCREMENT,
  `ProductName` VARCHAR(100) NOT NULL,
  `fk_supplier` INT NOT NULL,
  `ProductCategory` VARCHAR(50) NULL,
  `PricePerUnit` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`ProductId`),
  INDEX `fk_Products_Suppliers_idx` (`fk_supplier` ASC),
  CONSTRAINT `fk_Products_Suppliers`
    FOREIGN KEY (`fk_supplier`)
    REFERENCES `Suppliers` (`SupplierId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
);

-- Create Orders table
CREATE TABLE IF NOT EXISTS `Orders` (
  `OrderId` INT NOT NULL AUTO_INCREMENT,
  `OrderDate` DATE NOT NULL,
  `fk_customer` INT NOT NULL,
  `fk_employee` INT NOT NULL,
  `fk_shipper` INT NOT NULL,
  PRIMARY KEY (`OrderId`),
  INDEX `fk_Orders_Customers_idx` (`fk_customer` ASC),
  INDEX `fk_Orders_Employees_idx` (`fk_employee` ASC),
  INDEX `fk_Orders_Shippers_idx` (`fk_shipper` ASC),
  CONSTRAINT `fk_Orders_Customers`
    FOREIGN KEY (`fk_customer`)
    REFERENCES `Warehouse`.`Customers` (`CustomerId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Orders_Employees`
    FOREIGN KEY (`fk_employee`)
    REFERENCES `Warehouse`.`Employees` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Orders_Shippers`
    FOREIGN KEY (`fk_shipper`)
    REFERENCES `Warehouse`.`Shippers` (`ShipperId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
);

-- Create OrderDetails table
CREATE TABLE IF NOT EXISTS `OrderDetails` (
  `OrderDetailsId` INT NOT NULL AUTO_INCREMENT,
  `fk_order` INT NOT NULL,
  `fk_product` INT NOT NULL,
  `Quantity` INT NOT NULL,
  PRIMARY KEY (`OrderDetailsId`),
  INDEX `fk_OrderDetails_Orders_idx` (`fk_order` ASC),
  INDEX `fk_OrderDetails_Products_idx` (`fk_product` ASC),
  CONSTRAINT `fk_OrderDetails_Orders`
    FOREIGN KEY (`fk_order`)
    REFERENCES `Warehouse`.`Orders` (`OrderId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_OrderDetails_Products`
    FOREIGN KEY (`fk_product`)
    REFERENCES `Warehouse`.`Products` (`ProductId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
);