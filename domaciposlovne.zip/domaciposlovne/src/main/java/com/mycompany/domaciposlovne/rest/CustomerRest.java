/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.rest;

import com.mycompany.domaciposlovne.data.Customer;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import com.mycompany.domaciposlovne.service.CustomerService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import javax.ws.rs.core.Response;
/**
 *
 * @author mik
 */

@Path("customer")
public class CustomerRest {
    private final CustomerService customerService = CustomerService.getInstance();

    @GET()
    @Path("/all")
    public ArrayList<Customer> getAllCustomers() throws WarehouseException{
        return customerService.findAllCustomers();
    }

    @GET()
    @Path("/{customerId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Customer getCustomer(@PathParam("customerId") int customerId) throws WarehouseException{
        return customerService.findCustomer(customerId);
    }
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addCustomer(Customer customer) throws WarehouseException{
            customerService.addNewCustomer(customer);
            return Response.ok().build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateCustomer(Customer customer) throws WarehouseException {
            customerService.updateCustomer(customer);
            return Response.ok().build();
    }
    @DELETE
    @Path("/{employeeId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteCustomer(@PathParam("customerId") int customerId) throws WarehouseException {
            customerService.deleteCustomer(customerId);
            return Response.ok().build();
    }
    
    
}
