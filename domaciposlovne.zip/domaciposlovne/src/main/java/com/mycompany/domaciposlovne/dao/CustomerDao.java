/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.data.Customer;
public class CustomerDao {

    private static final CustomerDao instance = new CustomerDao();

    private CustomerDao() {
    }

    public static CustomerDao getInstance() {
        return instance;
    }
public void create(Connection con, Customer customer) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int id = -1;
        String sql = "INSERT INTO Customers (CustomerName, ContactPerson, Address, City, PostCode, Country) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getContactPerson());
            ps.setString(3, customer.getAddress());
            ps.setString(4, customer.getCity());
            ps.setString(5, customer.getPostCode());
            ps.setString(6, customer.getCountry());
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            rs.next();
            id = rs.getInt(1);
        }finally{
                      ResourcesManager.closeResources(rs,ps);

        }
    }
    public void update(Connection con, Customer customer) throws SQLException {
        PreparedStatement stmt=null;
        String sql = "UPDATE Customers SET CustomerName=?, ContactPerson=?, Address=?, City=?, PostCode=?, Country=? WHERE CustomerId=?";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setString(1, customer.getCustomerName());
            stmt.setString(2, customer.getContactPerson());
            stmt.setString(3, customer.getAddress());
            stmt.setString(4, customer.getCity());
            stmt.setString(5, customer.getPostCode());
            stmt.setString(6, customer.getCountry());
            stmt.setInt(7, customer.getCustomerId());
            stmt.executeUpdate();
        }finally{
                ResourcesManager.closeResources(null,stmt);
        }
        
    }
    
    
    public void delete(Connection con, int customerId) throws SQLException {
        String sql = "DELETE FROM Customers WHERE CustomerId=?";
        PreparedStatement stmt=null;
        try {
            stmt= con.prepareStatement(sql);
            stmt.setInt(1, customerId);
            stmt.executeUpdate();
        }
        finally{
                            ResourcesManager.closeResources(null,stmt);
        }
    }

   public Customer find(Connection con, int customerId) throws SQLException {
       PreparedStatement ps = null;
        ResultSet rs = null;
        Customer customer = null;
        try {
            ps=con.prepareStatement("SELECT * FROM Customers WHERE CustomerId=?");
            ps.setInt(1, customerId);
            rs=ps.executeQuery();
            
            if (rs.next()) {
                customer=new Customer(customerId,rs.getString("CustomerName"),rs.getString("ContactPerson"),rs.getString("Address"),rs.getString("City"),rs.getString("PostCode"),rs.getString("Country"));
            }
            else{
                return null;
            }
            
        }finally{
                        ResourcesManager.closeResources(rs, ps);

        }
        return customer;
    }
  
   public ArrayList<Customer> findAll(Connection con) throws SQLException{
        PreparedStatement ps=null;
        ResultSet rs=null;
        ArrayList <Customer> customers=new ArrayList<Customer>();
        String sql="SELECT * FROM Customers";
        try{
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                customers.add(new Customer(rs.getInt("CustomerId"), rs.getString("CustomerName"), rs.getString("ContactPerson"), rs.getString("Address"), rs.getString("City"), rs.getString("PostCode"),rs.getString("Country")));
            }}
            finally{
                    ResourcesManager.closeResources(rs,ps);
                    }
        return customers;
        
    }
   
}
