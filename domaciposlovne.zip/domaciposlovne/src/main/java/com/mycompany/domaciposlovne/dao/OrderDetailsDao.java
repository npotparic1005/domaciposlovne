/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.domaciposlovne.data.Order;
import com.mycompany.domaciposlovne.data.Product;
import com.mycompany.domaciposlovne.data.OrderDetails;


import com.mycompany.domaciposlovne.dao.ResourcesManager;

public class OrderDetailsDao {

    private static final OrderDetailsDao instance = new OrderDetailsDao();

    private OrderDetailsDao() {
    }

    public static OrderDetailsDao getInstance() {
        return instance;
    }

    public void create(Connection con, OrderDetails orderDetails) throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            if (orderDetails.getOrder() != null) {
                //insert address and receive the value of id
                OrderDao.getInstance().create( orderDetails.getOrder(),con);
            }
            if (orderDetails.getProduct() != null) {
                ProductDao.getInstance().create(con, orderDetails.getProduct());
            }

    
            stmt= con.prepareStatement("INSERT INTO OrderDetails (fk_order, fk_product, Quantity) VALUES (?, ?, ?)") ;
        
            stmt.setInt(1, orderDetails.getOrder().getOrderId());
            stmt.setInt(2, orderDetails.getProduct().getProductId());
            stmt.setInt(3, orderDetails.getQuantity());
            stmt.executeUpdate();
        }finally{
            ResourcesManager.closeResources(rs, stmt);
    }
       
    }

    public void update(Connection con, OrderDetails orderDetails) throws SQLException {
        PreparedStatement stmt = null;
        String sql = "UPDATE OrderDetails SET fk_order=?, fk_product=?, Quantity=? WHERE OrderDetailsId=?";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, orderDetails.getOrder().getOrderId());
            stmt.setInt(2, orderDetails.getProduct().getProductId());
            stmt.setInt(3, orderDetails.getQuantity());
            stmt.setInt(4, orderDetails.getOrderDetailsId());
            stmt.executeUpdate();
            if (orderDetails.getOrder() != null) {
                OrderDao.getInstance().update( orderDetails.getOrder(),con);
            }

            //update employee
            if (orderDetails.getProduct() != null) {
                ProductDao.getInstance().update(con, orderDetails.getProduct());
            }

            
        }finally{
            ResourcesManager.closeResources(null, stmt);

        }
    }

    public void delete(Connection con, int orderDetailsId) throws SQLException {
        String sql = "DELETE FROM OrderDetails WHERE OrderDetailsId=?";
        PreparedStatement stmt = con.prepareStatement(sql);

        try{
            stmt.setInt(1, orderDetailsId);
            stmt.executeUpdate();
            OrderDetails orderDetails = OrderDetailsDao.getInstance().find( con,orderDetailsId);

            if (orderDetails.getOrder() != null) {
                OrderDao.getInstance().delete( orderDetails.getOrder().getOrderId(),con);
            }

            //update employee
            if (orderDetails.getProduct() != null) {
                ProductDao.getInstance().delete(con, orderDetails.getProduct().getProductId());
            }
        }finally{
            ResourcesManager.closeResources(null, stmt);

        }
    }

    public OrderDetails find(Connection con, int orderDetailsId) throws SQLException {
        String sql = "SELECT * FROM OrderDetails WHERE OrderDetailsId=?";
        PreparedStatement stmt = null;
        try {
            
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, orderDetailsId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Order order = OrderDao.getInstance().find(rs.getInt("fk_order"),con);
                    Product product = ProductDao.getInstance().find(con, rs.getInt("fk_product"));
                    return new OrderDetails(
                            rs.getInt("OrderDetailsId"),
                            order,
                            product,
                            rs.getInt("Quantity")
                    );
                }
            }
        }finally{
            ResourcesManager.closeResources(null, stmt);

        }
        return null;
    }

    public ArrayList<OrderDetails> findAll(Connection con) throws SQLException {
        ArrayList<OrderDetails> orderDetailsList = new ArrayList<>();
        PreparedStatement stmt=null;
        ResultSet rs=null;
        String sql = "SELECT * FROM OrderDetails";
        try{
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                Order order = OrderDao.getInstance().find(rs.getInt("fk_order"),con);
                Product product = ProductDao.getInstance().find(con, rs.getInt("fk_product"));
                OrderDetails orderDetails = new OrderDetails(
                        rs.getInt("OrderDetailsId"),
                        order,
                        product,
                        rs.getInt("Quantity")
                );
                orderDetailsList.add(orderDetails);
            }
        }finally{
            ResourcesManager.closeResources(rs, stmt);

        }
        return orderDetailsList;
    }
     public ArrayList<OrderDetails> findOrderDetailsByOrder(int orderId, Connection con) throws SQLException {
        ArrayList<OrderDetails> orderDetailsList = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement("SELECT * FROM OrderDetails WHERE fk_order = ?")) {
            ps.setInt(1, orderId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order order = OrderDao.getInstance().find(rs.getInt("fk_order"), con);
                    Product product = ProductDao.getInstance().find(con, rs.getInt("fk_product"));

                    OrderDetails orderDetails = new OrderDetails(
                            rs.getInt("OrderDetailsId"),
                            order,
                            product,
                            rs.getInt("Quantity")
                    );

                    orderDetailsList.add(orderDetails);
                }
            }
        }

        return orderDetailsList;
    }
    public ArrayList<OrderDetails> findOrderDetailsByProduct(int productId, Connection con) throws SQLException {
        ArrayList<OrderDetails> orderDetailsList = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement("SELECT * FROM OrderDetails WHERE fk_product = ?")) {
            ps.setInt(1, productId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = ProductDao.getInstance().find(con,rs.getInt("fk_product"));
                    Order order = OrderDao.getInstance().find(rs.getInt("fk_order"),con);

                    OrderDetails orderDetails = new OrderDetails(
                            rs.getInt("OrderDetailsId"),
                            order,
                            product,
                            rs.getInt("Quantity")
                    );

                    orderDetailsList.add(orderDetails);
                }
            }
        }

        return orderDetailsList;
    }
}
