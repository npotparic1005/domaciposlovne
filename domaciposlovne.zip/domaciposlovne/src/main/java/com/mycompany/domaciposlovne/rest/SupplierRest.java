/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.rest;

/**
 *
 * @author mik
 */
import com.mycompany.domaciposlovne.data.Supplier;
import com.mycompany.domaciposlovne.service.SupplierService;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import javax.ws.rs.core.Response;

@Path("supplier")
public class SupplierRest {
    private final SupplierService supplierService = SupplierService.getInstance();
    
    @GET()
    @Path("/all")
    public ArrayList<Supplier> getAllSuppliers() throws WarehouseException{
        return supplierService.findAllSuppliers();
    }
    @GET()
    @Path("/{supplierId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Supplier getSupplier(@PathParam("supplierId") int supplierId) throws WarehouseException{
        return supplierService.findSupplier(supplierId);
    }
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addSupplier(Supplier supplier) throws WarehouseException{
            supplierService.addNewSupplier(supplier);
            return Response.ok().build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateSupplier(Supplier supplier) throws WarehouseException {
            supplierService.updateSupplier(supplier);
            return Response.ok().build();
    }
    @DELETE
    @Path("/{supplierId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteSupplier(@PathParam("supplierId") int supplierId) throws WarehouseException {
            supplierService.deleteSupplier(supplierId);
            return Response.ok().build();
    }
}    
    
    
