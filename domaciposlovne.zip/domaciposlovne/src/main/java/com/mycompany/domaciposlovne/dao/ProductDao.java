/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.domaciposlovne.data.Supplier;
import com.mycompany.domaciposlovne.data.Product;



public class ProductDao {

    private static final ProductDao instance = new ProductDao();

    private ProductDao() {
    }

    public static ProductDao getInstance() {
        return instance;
    }

    public void create(Connection con, Product product) throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            Integer supplierId = createSupplierIfNotNull(product.getSupplier(), con);

            stmt = con.prepareStatement("INSERT INTO Products (ProductName, fk_supplier, ProductCategory, PricePerUnit) VALUES (?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, product.getProductName());
            stmt.setInt(2, supplierId);
            stmt.setString(3, product.getProductCategory());
            stmt.setDouble(4, product.getPricePerUnit());
            stmt.executeUpdate();

            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedProductId = rs.getInt(1);
                product.setProductId(generatedProductId);
            }
        } finally {
            ResourcesManager.closeResources(rs, stmt);
        }
    }

    public void update(Connection con, Product product) throws SQLException {
        PreparedStatement stmt = null;
        try {
            updateSupplierIfNotNull(product.getSupplier(), con);

            stmt = con.prepareStatement("UPDATE Products SET ProductName=?, fk_supplier=?, ProductCategory=?, PricePerUnit=? WHERE ProductId=?");
            stmt.setString(1, product.getProductName());
            stmt.setInt(2, product.getSupplier().getSupplierId());
            stmt.setString(3, product.getProductCategory());
            stmt.setDouble(4, product.getPricePerUnit());
            stmt.setInt(5, product.getProductId());
            stmt.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, stmt);
        }
    }

    public void delete(Connection con, int productId) throws SQLException {
        String sql = "DELETE FROM Products WHERE ProductId=?";
        PreparedStatement stmt = con.prepareStatement(sql);
        try {
            stmt.setInt(1, productId);
            stmt.executeUpdate();
            Product product = ProductDao.getInstance().find(con, productId);

            deleteSupplierIfNotNull(product.getSupplier(), con);
        } finally {
            ResourcesManager.closeResources(null, stmt);
        }
    }

    public Product find(Connection con, int productId) throws SQLException {
        String sql = "SELECT * FROM Products WHERE ProductId=?";
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, productId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Supplier supplier = SupplierDao.getInstance().find(con, rs.getInt("fk_supplier"));
                    return new Product(
                            rs.getInt("ProductId"),
                            rs.getString("ProductName"),
                            supplier,
                            rs.getString("ProductCategory"),
                            rs.getDouble("PricePerUnit")
                    );
                }
            }
        } finally {
            ResourcesManager.closeResources(null, stmt);
        }
        return null;
    }

    public ArrayList<Product> findAll(Connection con) throws SQLException {
        ArrayList<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM Products";
        PreparedStatement stmt = null;
        ResultSet rs =null;
        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                Supplier supplier = SupplierDao.getInstance().find(con, rs.getInt("fk_supplier"));
                Product product = new Product(
                        rs.getInt("ProductId"),
                        rs.getString("ProductName"),
                        supplier,
                        rs.getString("ProductCategory"),
                        rs.getDouble("PricePerUnit")
                );
                productList.add(product);
            }
        }finally {
            ResourcesManager.closeResources(rs, stmt);
        }
        return productList;
    }


    private Integer createSupplierIfNotNull(Supplier supplier, Connection con) throws SQLException {
        if (supplier != null) {
            SupplierDao.getInstance().create(con, supplier);
            return supplier.getSupplierId();
        }
        return null;
    }

    private void updateSupplierIfNotNull(Supplier supplier, Connection con) throws SQLException {
        if (supplier != null) {
            SupplierDao.getInstance().update(con, supplier);
        }
    }

    private void deleteSupplierIfNotNull(Supplier supplier, Connection con) throws SQLException {
        if (supplier != null) {
            SupplierDao.getInstance().delete(con, supplier.getSupplierId());
        }
    }
    public void findProductsBySupplier(int supplierId, Connection con) throws SQLException {
        //ArrayList<Product> products = new ArrayList<>();
        String query = "SELECT * FROM Products WHERE fk_supplier = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setInt(1, supplierId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Product product = ProductDao.getInstance().find(con,resultSet.getInt("ProductId"));
                    System.out.println(product+"\n");
                    //products.add(product);
                }
            }
        }
        //return products;
    }
    public ArrayList<Product> findProductsBySupplier2(int supplierId, Connection con) throws SQLException {
        ArrayList<Product> products = new ArrayList<>();
        String query = "SELECT * FROM Products WHERE fk_supplier = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setInt(1, supplierId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Product product = ProductDao.getInstance().find(con,resultSet.getInt("ProductId"));
                    //System.out.println(product+"\n");
                    products.add(product);
                }
            }
        }
        return products;
    }
    
            
    public void findProductsByShipper(int shipperId, Connection con) throws SQLException {
        //ArrayList<Product> products = new ArrayList<>();
        String query = "SELECT * FROM Product WHERE fk_shipper = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setInt(1, shipperId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Product product = ProductDao.getInstance().find(con,resultSet.getInt("ProductId"));
                    System.out.println(product+"\n");
                    //products.add(product);
                }
            }
        }
        //return products;
    }
    
}
