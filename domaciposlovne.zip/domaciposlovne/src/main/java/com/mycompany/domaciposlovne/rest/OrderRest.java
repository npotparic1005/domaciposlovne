/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.rest;

/**
 *
 * @author mik
 */
import com.mycompany.domaciposlovne.data.Order;
import com.mycompany.domaciposlovne.service.OrderService;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import javax.ws.rs.core.Response;

@Path("order")
public class OrderRest {
    private final OrderService orderService = OrderService.getInstance();
    
    @GET()
    @Path("/all")
    public ArrayList<Order> getAllOrders() throws WarehouseException{
        return orderService.findAllOrders();
    }
    @GET()
    @Path("/{orderId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Order getOrder(@PathParam("orderId") int orderId) throws WarehouseException{
        return orderService.findOrder(orderId);
    }
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addOrder(Order order) throws WarehouseException{
            //orderService.addNewOrder(order);
            return Response.ok().build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateOrder(Order order) throws WarehouseException {
            orderService.updateOrder(order);
            return Response.ok().build();
    }
    @DELETE
    @Path("/{orderId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteOrder(@PathParam("orderId") int orderId) throws WarehouseException {
            orderService.deleteOrder(orderId);
            return Response.ok().build();
    }
    
    
    
}
