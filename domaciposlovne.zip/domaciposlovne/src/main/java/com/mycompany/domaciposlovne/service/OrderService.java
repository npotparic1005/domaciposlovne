/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.service;

/**
 *
 * @author mik
 */
import java.sql.Connection;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.dao.ResourcesManager;
import com.mycompany.domaciposlovne.dao.OrderDao;
import com.mycompany.domaciposlovne.data.Order;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import java.util.*;

public class OrderService {

    private static final OrderService instance = new OrderService();

    private OrderService() {
    }

    public static OrderService getInstance() {
        return instance;
    }

    public void addNewOrder(Order order) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            // More than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            OrderDao.getInstance().create(order,con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to create order " + order, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Order findOrder(int orderId) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            return OrderDao.getInstance().find(orderId, con);

        } catch (SQLException ex) {
            throw new WarehouseException("Failed to find order with id " + orderId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteOrder(int orderId) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            Order order = OrderDao.getInstance().find(orderId, con);
            if (order != null) {
                OrderDao.getInstance().delete(orderId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to delete order with id " + orderId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateOrder(Order order) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            OrderDao.getInstance().update(order, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to update order " + order, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public ArrayList<Order> findAllOrders() throws WarehouseException{
         Connection con=null;
         try{
             con=ResourcesManager.getConnection();
             return OrderDao.getInstance().findAll(con);
         }catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to find all orders", ex);}
         finally{
             ResourcesManager.closeConnection(con);
         }
     }
}
