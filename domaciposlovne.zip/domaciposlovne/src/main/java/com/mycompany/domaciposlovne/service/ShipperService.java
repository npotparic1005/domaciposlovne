/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.service;

import java.sql.Connection;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.dao.ResourcesManager;
import com.mycompany.domaciposlovne.dao.ShipperDao;
import com.mycompany.domaciposlovne.data.Shipper;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import java.util.ArrayList;

/**
 *
 * @author mik
 */
public class ShipperService {

    private static final ShipperService instance = new ShipperService();

    private ShipperService() {
    }

    public static ShipperService getInstance() {
        return instance;
    }

    public void addNewShipper(Shipper shipper) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            ShipperDao.getInstance().create(con, shipper);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to add new shipper " + shipper, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Shipper findShipper(int id) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            return ShipperDao.getInstance().find(con, id);

        } catch (SQLException ex) {
            throw new WarehouseException("Failed to find shipper with id " + id, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteShipper(int id) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            Shipper shipper = ShipperDao.getInstance().find(con, id);
            if (shipper != null) {
                ShipperDao.getInstance().delete(con, id);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to delete shipper with id " + id, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateShipper(Shipper shipper) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            ShipperDao.getInstance().update(con, shipper);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to update shipper " + shipper, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public ArrayList<Shipper> findAllShippers() throws WarehouseException{
         Connection con=null;
         try{
             con=ResourcesManager.getConnection();
             return ShipperDao.getInstance().findAll(con);
         }catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to find all shippers", ex);}
         finally{
             ResourcesManager.closeConnection(con);
         }
     }
}
