/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.data.Employee;
public class EmployeeDao {

    private static final EmployeeDao instance = new EmployeeDao();

    private EmployeeDao() {
    }

    public static EmployeeDao getInstance() {
        return instance;
    }

    public void create(Connection con, Employee employee) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int id = -1;
        String sql = "INSERT INTO Employees (LastName, FirstName, BirthDate) VALUES (?, ?, ?)";
        try {
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, employee.getLastName());
            ps.setString(2, employee.getFirstName());
            ps.setDate(3, employee.getBirthDate());
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } finally {
            // Zatvaranje resursa
        }
    }

    public void update(Connection con, Employee employee) throws SQLException {
        String sql = "UPDATE Employees SET LastName=?, FirstName=?, BirthDate=? WHERE EmployeeId=?";
        PreparedStatement stmt = null;
        try  {
            stmt = con.prepareStatement(sql);
            stmt.setString(1, employee.getLastName());
            stmt.setString(2, employee.getFirstName());
            stmt.setDate(3, employee.getBirthDate());
            stmt.setInt(4, employee.getEmployeeId());
            stmt.executeUpdate();
        }finally{
                      ResourcesManager.closeResources(null,stmt);

        }
    }

    public void delete(Connection con, int employeeId) throws SQLException {
        String sql = "DELETE FROM Employees WHERE EmployeeId=?";
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, employeeId);
            stmt.executeUpdate();
        }finally{
                      ResourcesManager.closeResources(null,stmt);

        }
    }

    public Employee find(Connection con, int employeeId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Employee employee = null;
        String sql = "SELECT * FROM Employees WHERE EmployeeId=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, employeeId);
            rs = ps.executeQuery();

            if (rs.next()) {
                employee = new Employee();
                employee.setEmployeeId(employeeId);
                employee.setLastName(rs.getString("LastName"));
                employee.setFirstName(rs.getString("FirstName"));
                employee.setBirthDate(rs.getDate("BirthDate"));
            }
        } finally{
                      ResourcesManager.closeResources(rs,ps);

        }
        return employee;
    }

    public ArrayList<Employee> findAll(Connection con) throws SQLException {
        ArrayList<Employee> employees = new ArrayList<>();
        String sql = "SELECT * FROM Employees";
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
             stmt = con.prepareStatement(sql);
              rs = stmt.executeQuery();
            while (rs.next()) {
                employees.add(mapResultSetToEmployee(rs));
            }
        }finally{
                      ResourcesManager.closeResources(rs,stmt);

        }
        return employees;
    }

    private Employee mapResultSetToEmployee(ResultSet rs) throws SQLException {
        Employee employee = new Employee();
        employee.setEmployeeId(rs.getInt("EmployeeId"));
        employee.setLastName(rs.getString("LastName"));
        employee.setFirstName(rs.getString("FirstName"));
        employee.setBirthDate(rs.getDate("BirthDate"));
        return employee;
    }
}
