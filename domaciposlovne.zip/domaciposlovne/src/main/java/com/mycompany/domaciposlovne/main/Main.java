/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.main;

/**
 *
 * @author mik
 */
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.domaciposlovne.data.Order;
import com.mycompany.domaciposlovne.dao.ResourcesManager;
import com.mycompany.domaciposlovne.data.Customer;
import com.mycompany.domaciposlovne.data.Employee;
import com.mycompany.domaciposlovne.data.OrderDetails;
import com.mycompany.domaciposlovne.data.Product;
import com.mycompany.domaciposlovne.data.Shipper;
import com.mycompany.domaciposlovne.data.Supplier;

import com.mycompany.domaciposlovne.service.CustomerService;
import com.mycompany.domaciposlovne.service.EmployeeService;
import com.mycompany.domaciposlovne.service.ShipperService;
import com.mycompany.domaciposlovne.service.SupplierService;
import com.mycompany.domaciposlovne.service.OrderService;
import com.mycompany.domaciposlovne.service.OrderDetailsService;
import com.mycompany.domaciposlovne.service.ProductService;
import com.mycompany.domaciposlovne.service.AdvancedService;

import java.time.LocalDate;
import com.mycompany.domaciposlovne.data.Customer;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import java.sql.Date;


public class Main {
    private static final CustomerService customerService = CustomerService.getInstance();
    private static final EmployeeService employeeService = EmployeeService.getInstance();
    private static final ShipperService shipperService = ShipperService.getInstance();
    private static final SupplierService supplierService = SupplierService.getInstance();
    private static final OrderService orderService = OrderService.getInstance();
    private static final ProductService productService = ProductService.getInstance();
    private static final OrderDetailsService orderDetailsService = OrderDetailsService.getInstance();
    private static final AdvancedService ad = AdvancedService.getInstance();


     
    public static void main(String[] args) throws Exception {
        //dodavanje u tabele
        
       //addtestCustomers();
       //addTestEmployees();
        //addTestShippers();
        //addTestSuppliers();
        /*
        //provera da li je dodat customer
        System.out.print(findCustomer());
        System.out.println( "\n");
        //provera da li se updatuje
        updateCustomer();
        System.out.print(findCustomer());
        System.out.println( "\n");
        
        //provera da li je dodat shipper
        System.out.println(findShipper());
        System.out.println( "\n");
        //provera da li se updatuje
        updateShipper();
        System.out.println(findShipper());
        System.out.println( "\n");

        //provera da li se dodaje radnik
        System.out.println(findEmployee());
        System.out.println( "\n");
        //provera da li se updatuje
        updateEmployee();
        System.out.println(findEmployee());
        System.out.println( "\n");
        
        //provera da li se dodaje supplier
        System.out.println(findSupplier());
        System.out.println( "\n");
        //provera da li se updatuje
        updateSupplier();
        System.out.println(findSupplier());
        System.out.println( "\n");

        //test supplier za product
        Supplier suppliertest= supplierService.findSupplier(1);
        System.out.println(suppliertest);
        System.out.println( "\n");
        
        // test customer, employee i shipper za order
        Customer customerTest = customerService.findCustomer(1);

        Employee employeeTest = employeeService.findEmployee(1);

        // Print Shipper details
        Shipper shipperTest = shipperService.findShipper(1);
        
        //dodavanje proizvoda
        //productService.addNewProduct(new Product("Laptop", supplier2, "Electronics", 999.99));
        //productService.addNewProduct(new Product("Smartphone", supplier2, "Electronics", 499.99));
        //provera da li je dodat
        System.out.print(productService.findProduct(2));
        System.out.println( "\n");
        //provera updatea
        productService.updateProduct(new Product(2, "Airbuds",suppliertest , "Electronics", 549.99));
        System.out.print(productService.findProduct(2));
        System.out.println( "\n");
        
        //dodavanje ordera
        orderService.addNewOrder(new Order(java.sql.Date.valueOf(LocalDate.of(2000, 5, 12)),customerTest,employeeTest,shipperTest));
        //orderService.addNewOrder(new Order(java.sql.Date.valueOf(LocalDate.of(1990, 5, 15)),customerTest,employeeTest,shipperTest));
        
         //provera da li je order dodat
         System.out.println(orderService.findOrder(1)) ;
        // update
        orderService.updateOrder(new Order(1,java.sql.Date.valueOf(LocalDate.of(2005, 5, 23)),customerTest,employeeTest,shipperTest));
        System.out.println(orderService.findOrder(1)) ;
        
        //dodavanje orderdetails
        Order ordertest=orderService.findOrder(1);
        Product producttest=productService.findProduct(1);
        //orderDetailsService.addNewOrderDetails(new OrderDetails(ordertest,producttest,5));
        //orderDetailsService.addNewOrderDetails(new OrderDetails(ordertest,producttest,10));
        System.out.println(orderDetailsService.findOrderDetails(1)) ;
        orderDetailsService.updateOrderDetails(new OrderDetails(1,ordertest,producttest,20));
        System.out.println(orderDetailsService.findOrderDetails(1)) ;
        
        */
        
        System.out.println("----------------prvi upit----------------------") ;
        System.out.println( "\n");
        ad.listCustomersAndOrders();
        System.out.println("----------------drugi upit----------------------") ;
        System.out.println( "\n");
        ad.listProductsBySupplier(1);
        System.out.println("----------------treci upit----------------------") ;
        System.out.println( "\n");
        ad.listProductsByShipper(1);
        System.out.println("----------------cetvrti upit----------------------") ;
        System.out.println( "\n");
        System.out.println( ad.calculateTotalPrice());
        System.out.println("----------------peti upit----------------------") ;
        System.out.println( "\n");
        System.out.println( ad.calculateOrderPriceByShipper(1));
        System.out.println("----------------sesti upit----------------------") ;
        System.out.println( "\n");
        System.out.println( ad.calculateOrderPriceByCustomer(1));
        System.out.println("----------------sedmi upit----------------------") ;
        System.out.println( "\n");
        System.out.println( ad.calculateOrderPriceBySupplier(1));
        System.out.println( "\n");
        
        
        System.out.println("----------------izlistaj sve customere----------------------") ;
        
        ArrayList<Customer> customers=customerService.findAllCustomers() ;
    for (Customer customer : customers) {
    System.out.println("Customer ID: " + customer.getCustomerId());
    System.out.println("Customer Name: " + customer.getCustomerName());
    System.out.println("Contact Person: " + customer.getContactPerson());
    System.out.println("Address: " + customer.getAddress());
    System.out.println("City: " + customer.getCity());
    System.out.println("Post Code: " + customer.getPostCode());
    System.out.println("Country: " + customer.getCountry());
    System.out.println("----------------------------------------");
}
    ArrayList<Employee> employees = employeeService.findAllEmployees();
System.out.println("----------------izlistaj sve employe-e----------------------");
for (Employee employee : employees) {
    System.out.println("Employee ID: " + employee.getEmployeeId());
    System.out.println("Last Name: " + employee.getLastName());
    System.out.println("First Name: " + employee.getFirstName());
    System.out.println("Birth Date: " + employee.getBirthDate());
    System.out.println("----------------------------------------");
}

ArrayList<Shipper> shippers = shipperService.findAllShippers();
System.out.println("----------------izlistaj sve shippere----------------------");
for (Shipper shipper : shippers) {
    System.out.println("Shipper ID: " + shipper.getShipperId());
    System.out.println("Shipper Name: " + shipper.getShipperName());
    System.out.println("Phone: " + shipper.getPhone());
    System.out.println("----------------------------------------");
}

ArrayList<Supplier> suppliers = supplierService.findAllSuppliers();
System.out.println("----------------izlistaj sve suplier-e----------------------");
for (Supplier supplier : suppliers) {
    System.out.println("Supplier ID: " + supplier.getSupplierId());
    System.out.println("Supplier Name: " + supplier.getSupplierName());
    System.out.println("Contact Person: " + supplier.getContactPerson());
    System.out.println("Address: " + supplier.getAddress());
    System.out.println("City: " + supplier.getCity());
    System.out.println("Post Code: " + supplier.getPostCode());
    System.out.println("Country: " + supplier.getCountry());
    System.out.println("Phone: " + supplier.getPhone());
    System.out.println("----------------------------------------");
}

ArrayList<Product> products = productService.findAllProducts();
System.out.println("----------------izlistaj sve produkte----------------------");
for (Product product : products) {
    System.out.println("Product ID: " + product.getProductId());
    System.out.println("Product Name: " + product.getProductName());
    System.out.println("Supplier ID: " + product.getSupplier().getSupplierId());
    System.out.println("Product Category: " + product.getProductCategory());
    System.out.println("Price Per Unit: " + product.getPricePerUnit());
    System.out.println("----------------------------------------");
}

ArrayList<Order> orders = orderService.findAllOrders();
System.out.println("----------------izlistaj sve ordere----------------------");
for (Order order : orders) {
    System.out.println("Order ID: " + order.getOrderId());
    System.out.println("Order Date: " + order.getOrderDate());
    System.out.println("Customer ID: " + order.getCustomer().getCustomerId());
    System.out.println("Employee ID: " + order.getEmployee().getEmployeeId());
    System.out.println("Shipper ID: " + order.getShipper().getShipperId());
    System.out.println("----------------------------------------");
}


ArrayList<OrderDetails> orderDetailsList = orderDetailsService.findAllOrderDetails();
System.out.println("----------------izlistaj sve order detaile----------------------");
for (OrderDetails orderDetails : orderDetailsList) {
    System.out.println("Order Details ID: " + orderDetails.getOrderDetailsId());
    System.out.println("Order ID: " + orderDetails.getOrder().getOrderId());
    System.out.println("Product ID: " + orderDetails.getProduct().getProductId());
    System.out.println("Quantity: " + orderDetails.getQuantity());
    System.out.println("----------------------------------------");
}
//brisanje
customerService.deleteCustomer(3);
}
   
    private static void addTestCustomers() throws WarehouseException {
        customerService.addNewCustomer(new Customer("Niki", "Nikola", "Vladimira Rolovica", "Kragujevac", "34000", "Srbija"));
        customerService.addNewCustomer(new Customer("Nikola", "Niki", "BB", "Krusevac", "34000", "Srbija"));
     }
       private static Customer findCustomer() throws WarehouseException {
        return customerService.findCustomer(2);
       }
        private static void updateCustomer() throws WarehouseException{
            customerService.updateCustomer(new Customer(2, "Natalija", "Nikolina", "Kneza Mihaila", "Kragujevac", "34000", "Srbija"));
        }
    private static void addTestEmployees() throws WarehouseException {
    employeeService.addNewEmployee(new Employee("Stosic", "Jelena",java.sql.Date.valueOf(LocalDate.of(1990, 5, 15))));
    employeeService.addNewEmployee(new Employee("Potparic", "Nikola", java.sql.Date.valueOf(LocalDate.of(2000, 5, 15))));
}

private static Employee findEmployee() throws WarehouseException {
    return employeeService.findEmployee(2);
}

private static void updateEmployee() throws WarehouseException {
    employeeService.updateEmployee(new Employee(2, "Potparic", "Leki", java.sql.Date.valueOf(LocalDate.of(2000, 5, 15))));
}

    private static void addTestSuppliers() throws WarehouseException {
        supplierService.addNewSupplier(new Supplier("ABC Ltd.", "John Doe", "123 Main St", "Cityville", "12345", "CountryABC", "123-456-789"));
        supplierService.addNewSupplier(new Supplier("XYZ Inc.", "Jane Doe", "456 Oak St", "Townsville", "67890", "CountryXYZ", "987-654-321"));
    }

    private static Supplier findSupplier() throws WarehouseException {
        return supplierService.findSupplier(2);
    }

    private static void updateSupplier() throws WarehouseException {
        supplierService.updateSupplier(new Supplier(2, "Ivana", "Milica", "456 Oak St", "Townsville", "67890", "CountryXYZ", "987-654-321"));
    }

    private static void addTestShippers() throws WarehouseException {
        shipperService.addNewShipper(new Shipper("Fast Express", "123-456-789"));
        shipperService.addNewShipper(new Shipper("Swift Logistics", "987-654-321"));
    }
    private static Shipper findShipper() throws WarehouseException {
    return shipperService.findShipper(2);
}

private static void updateShipper() throws WarehouseException {
    shipperService.updateShipper(new Shipper(2, "XYZ Milica Express", "987-654-321"));
}



}
