/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.data;

/**
 *
 * @author mik
 */
import java.io.Serializable;

import java.sql.Date;

public class Order implements Serializable {
    private int orderId;
    private Date orderDate;
    private Customer customer;
    private Employee employee;
    private Shipper shipper;

    public Order() {
    }

    public Order(int orderId, Date orderDate, Customer customer, Employee employee, Shipper shipper) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.customer = customer;
        this.employee= employee;
        this.shipper= shipper;
    }
    public Order(Date orderDate, Customer customer, Employee employee, Shipper shipper) {
        this.orderDate = orderDate;
        this.customer = customer;
        this.employee= employee;
        this.shipper= shipper;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Customer  getCustomer() {
        return this.customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Employee getEmployee() {
        return this.employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Shipper getShipper() {
        return this.shipper;
    }

    public void setShipper(Shipper shipper) {
        this.shipper = shipper;
    }

    @Override
  public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Order{")
                .append("orderId=").append(orderId)
                .append(", orderDate=").append(orderDate)
                .append(", customer=").append(customer)
                .append(", employee=").append(employee)
                .append(", shipper=").append(shipper)
                .append("}");
        return sb.toString();
    }
}