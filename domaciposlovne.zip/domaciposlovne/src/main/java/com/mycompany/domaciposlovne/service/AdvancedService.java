/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.service;

/**
 *
 * @author mik
 */

import com.mycompany.domaciposlovne.data.Customer;
import com.mycompany.domaciposlovne.data.Order;
import com.mycompany.domaciposlovne.data.Product;
import com.mycompany.domaciposlovne.data.Shipper;
import com.mycompany.domaciposlovne.data.Supplier;
import com.mycompany.domaciposlovne.dao.CustomerDao;
import com.mycompany.domaciposlovne.dao.OrderDao;
import com.mycompany.domaciposlovne.dao.ProductDao;
import com.mycompany.domaciposlovne.dao.ShipperDao;
import com.mycompany.domaciposlovne.dao.SupplierDao;
import com.mycompany.domaciposlovne.dao.ResourcesManager;
import com.mycompany.domaciposlovne.dao.OrderDetailsDao;
import com.mycompany.domaciposlovne.data.OrderDetails;


import java.util.*;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;


public class AdvancedService {

    private static final AdvancedService instance = new AdvancedService();

    private AdvancedService() {
    }

    public static AdvancedService getInstance() {
        return instance;
    }

    //1. Metoda za izlistavanje Customer-a i njihovih Order-a po abecednom redu
    public void listCustomersAndOrders() throws SQLException {
        Connection con = ResourcesManager.getConnection();
        ArrayList<Customer> customers = CustomerDao.getInstance().findAll(con);
        customers.sort(Comparator.comparing(Customer::getCustomerName));

        for (Customer customer : customers) {
            System.out.println(customer.getCustomerName());
            ArrayList<Order> orders = OrderDao.getInstance().findOrdersByCustomer(customer.getCustomerId(),con);
            for (Order order : orders) {
                System.out.println(order+"\n ");
            }
        }
    }

    //2. Metoda za izlistavanje Product-a za određenog Supplier-a
    public void listProductsBySupplier(int supplierId) throws SQLException {
        Connection con = ResourcesManager.getConnection();
        Supplier supplier = SupplierDao.getInstance().find(con,supplierId);
        if (supplier != null) {
             ProductDao.getInstance().findProductsBySupplier(supplierId,con);
        }
    }

    //3. Metoda za izlistavanje Product-a koje je dostavio određeni Shipper
    public void listProductsByShipper(int shipperId) throws SQLException {
        Connection con = ResourcesManager.getConnection();
        Shipper shipper = ShipperDao.getInstance().find(con,shipperId);
        System.out.println("Sve porudzbine shippera sa ID:" +shipper.getShipperId()+"\n ");
        if (shipper != null) {
            ArrayList <Order> orders=OrderDao.getInstance().findOrdersByShipper(shipperId,con);
            for(Order order:orders){
                ArrayList<OrderDetails> orderDetailsList = OrderDetailsDao.getInstance().findOrderDetailsByOrder(order.getOrderId(), con);

                for (OrderDetails orderDetails : orderDetailsList) {
                    Product product = ProductDao.getInstance().find(con, orderDetails.getProduct().getProductId());
                    System.out.println(order+"\n ");
                }
                
            }
        }
    }
//4.Izracunaj ukupnu cenu svih narudzibina
   public double calculateTotalPrice() throws SQLException {
        double total = 0.0;

        try (Connection con = ResourcesManager.getConnection()) {
            ArrayList<Order> orders = OrderDao.getInstance().findAll(con);

            for (Order order : orders) {
                ArrayList<OrderDetails> orderDetailsList = OrderDetailsDao.getInstance().findOrderDetailsByOrder(order.getOrderId(), con);

                for (OrderDetails orderDetails : orderDetailsList) {
                    Product product = ProductDao.getInstance().find(con, orderDetails.getProduct().getProductId());
                    double PricePerUnit = product.getPricePerUnit();
                    int quantity = orderDetails.getQuantity();
                    total += PricePerUnit * quantity;
                }
            }
        }
        return total;
    }

    // 5. Metoda za izračunavanje cene narudžbina koje je naručio određeni Customer
    public double calculateOrderPriceByCustomer(int customerId) throws SQLException {
        Connection con = ResourcesManager.getConnection();
        Customer customer = CustomerDao.getInstance().find(con,customerId);
        double total=0;
        if (customer != null) {
            List<Order> orders = OrderDao.getInstance().findOrdersByCustomer(customerId,con);
            for (Order order : orders) {
                ArrayList<OrderDetails> orderDetailsList = OrderDetailsDao.getInstance().findOrderDetailsByOrder(order.getOrderId(), con);

                for (OrderDetails orderDetails : orderDetailsList) {
                    Product product = ProductDao.getInstance().find(con, orderDetails.getProduct().getProductId());
                    double PricePerUnit = product.getPricePerUnit();
                    int quantity = orderDetails.getQuantity();
                    total += PricePerUnit * quantity;
                }
            }
            return total;
        } else {
            return 0;
        }
    }

    //6. Metoda za izračunavanje cene narudžbina koje je dostavio određeni Shipper
    public double calculateOrderPriceByShipper(int shipperId) throws SQLException {
        Connection con = ResourcesManager.getConnection();
        Shipper shipper = ShipperDao.getInstance().find(con,shipperId);
        double total=0;
        if (shipper != null) {
            List<Order> orders = OrderDao.getInstance().findOrdersByShipper(shipperId,con);
            for (Order order : orders) {
                ArrayList<OrderDetails> orderDetailsList = OrderDetailsDao.getInstance().findOrderDetailsByOrder(order.getOrderId(), con);

                for (OrderDetails orderDetails : orderDetailsList) {
                    Product product = ProductDao.getInstance().find(con, orderDetails.getProduct().getProductId());
                    double PricePerUnit = product.getPricePerUnit();
                    int quantity = orderDetails.getQuantity();
                    total += PricePerUnit * quantity;
                }
            }
            return total;
        } else {
            return 0;
        }
    }
    
//7. Metoda za izračunavanje cene narudžbina koje je dobavio određeni Supplier
    public double calculateOrderPriceBySupplier(int supplierId) throws SQLException {
        Connection con = ResourcesManager.getConnection();
        Supplier supplier = SupplierDao.getInstance().find(con,supplierId);
        double total=0;
        if (supplier != null) {
            ArrayList<Product> products = ProductDao.getInstance().findProductsBySupplier2(supplierId,con);
            for (Product product : products) {
                ArrayList<OrderDetails> orderDetailsList = OrderDetailsDao.getInstance().findOrderDetailsByProduct(product.getProductId(), con);
                for (OrderDetails orderDetails : orderDetailsList) {
                    Order order = OrderDao.getInstance().find(orderDetails.getOrder().getOrderId(),con);
                    double PricePerUnit = product.getPricePerUnit();
                    int quantity = orderDetails.getQuantity();
                    total += PricePerUnit * quantity;
                }
            }
            return total;
        } else {
            return 0;
        }
                
    }
}

