/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.data.Shipper;
public class ShipperDao {

    private static final ShipperDao instance = new ShipperDao();

    private ShipperDao() {
    }

    public static ShipperDao getInstance() {
        return instance;
    }

    public void create(Connection con, Shipper shipper) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int id = -1;
        String sql = "INSERT INTO Shippers (ShipperName, Phone) VALUES (?, ?)";
        try {
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, shipper.getShipperName());
            ps.setString(2, shipper.getPhone());
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } finally{
                      ResourcesManager.closeResources(rs,ps);

        }
    }

    public void update(Connection con, Shipper shipper) throws SQLException {
        String sql = "UPDATE Shippers SET ShipperName=?, Phone=? WHERE ShipperId=?";
        PreparedStatement stmt = null;
        try {
             stmt = con.prepareStatement(sql);
            stmt.setString(1, shipper.getShipperName());
            stmt.setString(2, shipper.getPhone());
            stmt.setInt(3, shipper.getShipperId());
            stmt.executeUpdate();
        }
        finally{
                      ResourcesManager.closeResources(null,stmt);

        }
    }

    public void delete(Connection con, int shipperId) throws SQLException {
        String sql = "DELETE FROM Shippers WHERE ShipperId=?";
        PreparedStatement stmt=null;
        try { stmt = con.prepareStatement(sql);
            stmt.setInt(1, shipperId);
            stmt.executeUpdate();
        }
        finally{
                      ResourcesManager.closeResources(null,stmt);

        }
    }

    public Shipper find(Connection con, int shipperId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Shipper shipper = null;
        String sql = "SELECT * FROM Shippers WHERE ShipperId=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, shipperId);
            rs = ps.executeQuery();

            if (rs.next()) {
                shipper = new Shipper();
                shipper.setShipperId(shipperId);
                shipper.setShipperName(rs.getString("ShipperName"));
                shipper.setPhone(rs.getString("Phone"));
            }
        } finally{
                      ResourcesManager.closeResources(rs,ps);

        }
        return shipper;
    }

    public ArrayList<Shipper> findAll(Connection con) throws SQLException {
        ArrayList<Shipper> shippers = new ArrayList<>();
        String sql = "SELECT * FROM Shippers";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try { ps = con.prepareStatement(sql);
             rs = ps.executeQuery();
            while (rs.next()) {
                shippers.add(mapResultSetToShipper(rs));
            }
        }finally{
                      ResourcesManager.closeResources(rs,ps);

        }
        return shippers;
    }

    private Shipper mapResultSetToShipper(ResultSet rs) throws SQLException {
        Shipper shipper = new Shipper();
        shipper.setShipperId(rs.getInt("ShipperId"));
        shipper.setShipperName(rs.getString("ShipperName"));
        shipper.setPhone(rs.getString("Phone"));
        return shipper;
    }
}
