/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.service;

/**
 *
 * @author mik
 */
import java.sql.Connection;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.dao.ResourcesManager;
import com.mycompany.domaciposlovne.dao.ProductDao;
import com.mycompany.domaciposlovne.data.Product;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import java.util.*;
public class ProductService {

    private static final ProductService instance = new ProductService();

    private ProductService() {
    }

    public static ProductService getInstance() {
        return instance;
    }

    public void addNewProduct(Product product) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            // More than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            ProductDao.getInstance().create(con, product);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to create product " + product, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Product findProduct(int productId) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            return ProductDao.getInstance().find(con, productId);

        } catch (SQLException ex) {
            throw new WarehouseException("Failed to find product with id " + productId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteProduct(int productId) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            Product product = ProductDao.getInstance().find(con, productId);
            if (product != null) {
                ProductDao.getInstance().delete(con, productId);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to delete product with id " + productId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateProduct(Product product) throws WarehouseException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            ProductDao.getInstance().update(con, product);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to update product " + product, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public ArrayList<Product> findAllProducts() throws WarehouseException{
         Connection con=null;
         try{
             con=ResourcesManager.getConnection();
             return ProductDao.getInstance().findAll(con);
         }catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new WarehouseException("Failed to find all products", ex);}
         finally{
             ResourcesManager.closeConnection(con);
         }
     }
    
}
