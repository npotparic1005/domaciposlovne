/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.rest;

/**
 *
 * @author mik
 */
import com.mycompany.domaciposlovne.data.OrderDetails;
import com.mycompany.domaciposlovne.service.OrderDetailsService;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import javax.ws.rs.core.Response;

@Path("orderDetails")
public class OrderDetailsRest {
    private final OrderDetailsService orderDetailsService = OrderDetailsService.getInstance();
    
    @GET()
    @Path("/all")
    public ArrayList<OrderDetails> getAllOrderDetails() throws WarehouseException{
        return orderDetailsService.findAllOrderDetails();
    }
    @GET()
    @Path("/{orderDetailsId}")
    @Produces(MediaType.APPLICATION_JSON)
    public OrderDetails getOrderDetails(@PathParam("orderDetailsId") int orderDetailsId) throws WarehouseException{
        return orderDetailsService.findOrderDetails(orderDetailsId);
    }
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addOrderDetails(OrderDetails orderDetails) throws WarehouseException{
            orderDetailsService.addNewOrderDetails(orderDetails);
            return Response.ok().build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateOrderDetails(OrderDetails orderDetails) throws WarehouseException {
            orderDetailsService.updateOrderDetails(orderDetails);
            return Response.ok().build();
    }
    @DELETE
    @Path("/{orderDetailsId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteOrderDetails(@PathParam("orderDetailsId") int orderDetailsId) throws WarehouseException {
            orderDetailsService.deleteOrderDetails(orderDetailsId);
            return Response.ok().build();
    }
    
    
    
}
