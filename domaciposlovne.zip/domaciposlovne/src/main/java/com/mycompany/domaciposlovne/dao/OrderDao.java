/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.domaciposlovne.data.Order;
import com.mycompany.domaciposlovne.dao.ResourcesManager;
import com.mycompany.domaciposlovne.data.Customer;
import com.mycompany.domaciposlovne.data.Employee;
import com.mycompany.domaciposlovne.data.OrderDetails;
import com.mycompany.domaciposlovne.data.Product;
import com.mycompany.domaciposlovne.data.Shipper;




public class OrderDao {

    private static final OrderDao instance = new OrderDao();

    private OrderDao() {
    }

    public static OrderDao getInstance() {
        return instance;
    }

    public Order find(int orderId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Order order = null;
        try {
            ps = con.prepareStatement("SELECT * FROM Orders WHERE OrderId=?");
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                Customer customer = CustomerDao.getInstance().find(con, rs.getInt("fk_customer"));
                Shipper shipper = ShipperDao.getInstance().find(con, rs.getInt("fk_shipper"));
                Employee employee = EmployeeDao.getInstance().find(con, rs.getInt("fk_employee"));

                order = new Order(
                        rs.getInt("OrderId"),
                        rs.getDate("OrderDate"),
                        customer,
                        employee,
                        shipper
                );
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return order;
    }

    public void create(Order order, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            Integer fkCustomerId = null;
            if (order.getCustomer() != null) {
                //insert address and receive the value of id
                CustomerDao.getInstance().create(con, order.getCustomer());
                fkCustomerId=order.getCustomer().getCustomerId();
                
            }
            Integer fkEmployeeId=null;
            if (order.getEmployee() != null) {
                EmployeeDao.getInstance().create(con, order.getEmployee());
                fkEmployeeId=order.getEmployee().getEmployeeId();
            }

            //update shipper
            Integer fkShipperId=null;
            if (order.getShipper() != null) {
                ShipperDao.getInstance().update(con, order.getShipper());
                fkShipperId=order.getShipper().getShipperId();

            }
            ps = con.prepareStatement("INSERT INTO Orders (OrderDate, fk_customer, fk_employee, fk_shipper) VALUES (?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setDate(1, order.getOrderDate());
            ps.setInt(2, order.getCustomer().getCustomerId());
            ps.setInt(3, order.getEmployee().getEmployeeId());
            ps.setInt(4, order.getShipper().getShipperId());
            ps.executeUpdate();

            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int generatedOrderId = rs.getInt(1);
                order.setOrderId(generatedOrderId);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        
    }

    public void update(Order order, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("UPDATE Orders SET OrderDate=?, fk_customer=?, fk_employee=?, fk_shipper=? WHERE OrderId=?");
            ps.setDate(1, order.getOrderDate());
            ps.setInt(2, order.getCustomer().getCustomerId());
            ps.setInt(3, order.getEmployee().getEmployeeId());
            ps.setInt(4, order.getShipper().getShipperId());
            ps.setInt(5, order.getOrderId());
            ps.executeUpdate();
            //update customer
            if (order.getCustomer() != null) {
                CustomerDao.getInstance().update(con, order.getCustomer());
            }

            //update employee
            if (order.getEmployee() != null) {
                EmployeeDao.getInstance().update(con, order.getEmployee());
            }

            //update shipper
            if (order.getShipper() != null) {
                ShipperDao.getInstance().update(con, order.getShipper());
            }
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(int OrderId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("DELETE FROM Orders WHERE OrderId=?");
            ps.setInt(1, OrderId);
            ps.executeUpdate();
            Order order = OrderDao.getInstance().find( OrderId,con);

            //delete customer
            if (order.getCustomer() != null) {
                CustomerDao.getInstance().delete(con, order.getCustomer().getCustomerId());
            }

            //delete employee
            if (order.getEmployee() != null) {
                EmployeeDao.getInstance().delete(con, order.getEmployee().getEmployeeId());
            }

            //delete shipper
            if (order.getShipper() != null) {
                ShipperDao.getInstance().delete(con, order.getShipper().getShipperId());
            }
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    
    public ArrayList<Order> findAll(Connection con) throws SQLException {
        ArrayList<Order> orderList = new ArrayList<>();
        String sql = "SELECT * FROM Orders";
        PreparedStatement stmt= null;
        ResultSet rs = null;
        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                Customer customer = CustomerDao.getInstance().find(con,rs.getInt("fk_customer"));
                Employee employee = EmployeeDao.getInstance().find(con, rs.getInt("fk_employee"));
                Shipper shipper = ShipperDao.getInstance().find(con, rs.getInt("fk_shipper"));
                Order order = new Order(
                        rs.getInt("OrderId"),
                        rs.getDate("OrderDate"),
                        customer,
                        employee,
                        shipper
                );
                orderList.add(order);
            }
        }finally {
            ResourcesManager.closeResources(null, stmt);
        }
        return orderList;
    }
    

    public ArrayList<Order> findOrdersByCustomer(int customerId, Connection con) throws SQLException {
        ArrayList<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM Orders WHERE fk_customer = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setInt(1, customerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                Order order = OrderDao.getInstance().find(resultSet.getInt("OrderId"),con);
                orders.add(order);
                }
            }
        }
        return orders;
    }
    public ArrayList<Order> findOrdersByShipper(int shipperId, Connection con) throws SQLException {
        ArrayList<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM Orders WHERE fk_shipper = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setInt(1, shipperId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                Order order = OrderDao.getInstance().find(resultSet.getInt("OrderId"),con);
                orders.add(order);
                }
            }
        }
        return orders;
    }
    

}