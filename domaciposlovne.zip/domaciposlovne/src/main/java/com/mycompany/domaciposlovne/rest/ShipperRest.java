/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.rest;

/**
 *
 * @author mik
 */

import com.mycompany.domaciposlovne.data.Shipper;
import com.mycompany.domaciposlovne.service.ShipperService;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import javax.ws.rs.core.Response;

@Path("shipper")
public class ShipperRest {
    private final ShipperService shipperService = ShipperService.getInstance();
    
    @GET()
    @Path("/all")
    public ArrayList<Shipper> getAllShippers() throws WarehouseException{
        return shipperService.findAllShippers();
    }
    @GET()
    @Path("/{shipperId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Shipper getShipper(@PathParam("shipperId") int shipperId) throws WarehouseException{
        return shipperService.findShipper(shipperId);
    }
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addShipper(Shipper shipper) throws WarehouseException{
            shipperService.addNewShipper(shipper);
            return Response.ok().build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateShipper(Shipper shipper) throws WarehouseException {
            shipperService.updateShipper(shipper);
            return Response.ok().build();
    }
    @DELETE
    @Path("/{shipperId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteShipper(@PathParam("shipperId") int shipperId) throws WarehouseException {
            shipperService.deleteShipper(shipperId);
            return Response.ok().build();
    }
    
    
    
}
