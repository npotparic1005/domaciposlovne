/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.rest;

import com.mycompany.domaciposlovne.data.Employee;
import com.mycompany.domaciposlovne.exception.WarehouseException;
import com.mycompany.domaciposlovne.service.EmployeeService;


import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author Ivana
 */

@Path("employee")
public class EmployeeRest {
    private final EmployeeService employeeService = EmployeeService.getInstance();
    
    @GET()
    @Path("/all")
    public List<Employee> getAllEmployees() throws WarehouseException{
        return employeeService.findAllEmployees();
    }
    @GET()
    @Path("/{employeeId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Employee getEmployee(@PathParam("employeeId") int employeeId) throws WarehouseException{
        return employeeService.findEmployee(employeeId);
    }
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addEmployee(Employee employee) throws WarehouseException{
            employeeService.addNewEmployee(employee);
            return Response.ok().build();
    }
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateEmployee(Employee employee) throws WarehouseException {
            employeeService.updateEmployee(employee);
            return Response.ok().build();
    }
    @DELETE
    @Path("/{employeeId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteEmployee(@PathParam("employeeId") int employeeId) throws WarehouseException {
            employeeService.deleteEmployee(employeeId);
            return Response.ok().build();
    }
    
    
    
}
