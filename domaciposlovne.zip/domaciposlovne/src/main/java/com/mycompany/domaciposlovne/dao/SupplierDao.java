/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domaciposlovne.dao;

/**
 *
 * @author mik
 */
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mycompany.domaciposlovne.data.Supplier;

public class SupplierDao {

    private static final SupplierDao instance = new SupplierDao();

    private SupplierDao() {
    }

    public static SupplierDao getInstance() {
        return instance;
    }

    public void create(Connection con, Supplier supplier) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int id = -1;
        String sql = "INSERT INTO Suppliers (SupplierName, ContactPerson, Address, City, PostCode, Country, Phone) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, supplier.getSupplierName());
            ps.setString(2, supplier.getContactPerson());
            ps.setString(3, supplier.getAddress());
            ps.setString(4, supplier.getCity());
            ps.setString(5, supplier.getPostCode());
            ps.setString(6, supplier.getCountry());
            ps.setString(7, supplier.getPhone());
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } finally {
                      ResourcesManager.closeResources(rs,ps);
        }
    }

    public void update(Connection con, Supplier supplier) throws SQLException {
        PreparedStatement stmt=null;
        String sql = "UPDATE Suppliers SET SupplierName=?, ContactPerson=?, Address=?, City=?, PostCode=?, Country=?, Phone=? WHERE SupplierId=?";
        try {stmt = con.prepareStatement(sql);
            stmt.setString(1, supplier.getSupplierName());
            stmt.setString(2, supplier.getContactPerson());
            stmt.setString(3, supplier.getAddress());
            stmt.setString(4, supplier.getCity());
            stmt.setString(5, supplier.getPostCode());
            stmt.setString(6, supplier.getCountry());
            stmt.setString(7, supplier.getPhone());
            stmt.setInt(8, supplier.getSupplierId());
            stmt.executeUpdate();
        }finally {
                      ResourcesManager.closeResources(null,stmt);
        }
    }

    public void delete(Connection con, int supplierId) throws SQLException {
        String sql = "DELETE FROM Suppliers WHERE SupplierId=?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, supplierId);
            stmt.executeUpdate();
        }
    }

    public Supplier find(Connection con, int supplierId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Supplier supplier = null;
        String sql = "SELECT * FROM Suppliers WHERE SupplierId=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, supplierId);
            rs = ps.executeQuery();

            if (rs.next()) {
                supplier = new Supplier();
                supplier.setSupplierId(supplierId);
                supplier.setSupplierName(rs.getString("SupplierName"));
                supplier.setContactPerson(rs.getString("ContactPerson"));
                supplier.setAddress(rs.getString("Address"));
                supplier.setCity(rs.getString("City"));
                supplier.setPostCode(rs.getString("PostCode"));
                supplier.setCountry(rs.getString("Country"));
                supplier.setPhone(rs.getString("Phone"));
            }
        } finally {
                      ResourcesManager.closeResources(rs,ps);
        }
        return supplier;
    }

    public ArrayList<Supplier> findAll(Connection con) throws SQLException {
        ArrayList<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT * FROM Suppliers";
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {stmt = con.prepareStatement(sql);
              rs = stmt.executeQuery();
            while (rs.next()) {
                suppliers.add(mapResultSetToSupplier(rs));
            }
        }finally {
                      ResourcesManager.closeResources(rs,stmt);
        }
        return suppliers;
    }

    private Supplier mapResultSetToSupplier(ResultSet rs) throws SQLException {
        Supplier supplier = new Supplier();
        supplier.setSupplierId(rs.getInt("SupplierId"));
        supplier.setSupplierName(rs.getString("SupplierName"));
        supplier.setContactPerson(rs.getString("ContactPerson"));
        supplier.setAddress(rs.getString("Address"));
        supplier.setCity(rs.getString("City"));
        supplier.setPostCode(rs.getString("PostCode"));
        supplier.setCountry(rs.getString("Country"));
        supplier.setPhone(rs.getString("Phone"));
        return supplier;
    }
}
